#!/bin/bash
# start_llama.sh — запуск llama.cpp сервера
#
# Использование:
#   ./start_llama.sh [МОДЕЛЬ] [ПОРТ]
#
# Аргументы:
#   МОДЕЛЬ   — имя модели (по умолчанию: translategemma)
#   ПОРТ     — порт сервера (по умолчанию: 8080)
#
# Примеры:
#   ./start_llama.sh              # translategemma на порту 8080
#   ./start_llama.sh smollm 8081  # smollm на порту 8081

set -euo pipefail

# ----------------------------------------------------------------------
# Настройки по умолчанию
# ----------------------------------------------------------------------
MODEL="${1:-translategemma}"          # <-- изменено на translategemma
PORT="${2:-8080}"

# Каталог с моделями (можно переопределить через переменную окружения)
MODELS_DIR="${MODELS_DIR:-/home/ad/llm_models}"
LOG_FILE="${LOG_FILE:-/tmp/llama-server.log}"

# ----------------------------------------------------------------------
# Поиск бинарника llama-server
# ----------------------------------------------------------------------
find_llama_server() {
    local candidates=(
        "/opt/llama.cpp/llama-server"
        "/usr/local/bin/llama-server"
        "$HOME/bin/llama-server"
        "$(command -v llama-server 2>/dev/null || echo '')"
    )
    for cand in "${candidates[@]}"; do
        if [[ -x "$cand" ]]; then
            echo "$cand"
            return 0
        fi
    done
    return 1
}

LLAMA_SERVER="$(find_llama_server)"
if [[ -z "$LLAMA_SERVER" ]]; then
    echo "ОШИБКА: llama-server не найден ни в /opt, ни в PATH" >&2
    exit 1
fi

# ----------------------------------------------------------------------
# Проверка занятости порта (без lsof, через ss или netstat)
# ----------------------------------------------------------------------
port_busy() {
    local port="$1"
    if command -v ss >/dev/null 2>&1; then
        ss -lpn "sport = :$port" 2>/dev/null | grep -q LISTEN
    elif command -v netstat >/dev/null 2>&1; then
        netstat -tulpn 2>/dev/null | grep -q ":$port "
    elif command -v lsof >/dev/null 2>&1; then
        lsof -i :"$port" -sTCP:LISTEN >/dev/null 2>&1
    else
        # Если ни одна утилита не доступна, считаем порт свободным
        return 1
    fi
}

if port_busy "$PORT"; then
    echo "Сервер уже запущен на порту $PORT"
    exit 0
fi

# ----------------------------------------------------------------------
# Маппинг имён моделей на файлы GGUF (с поддержкой fallback)
# ----------------------------------------------------------------------
resolve_gguf() {
    local model="$1"
    local gguf_path=""

    case "$model" in
        translategemma|translate-gemma)
            gguf_path="$MODELS_DIR/translategemma-4b-it-Q4_K_M_GGUF.gguf"
            if [[ ! -f "$gguf_path" ]]; then
                # Fallback на gemma, если translategemma отсутствует
                echo "Модель translategemma не найдена, пробую gemma как fallback" >&2
                gguf_path="$MODELS_DIR/gemma-4-E4B-it-Q4_K_M.gguf"
            fi
            ;;
        gemma|gemma-4|gemma4)
            gguf_path="$MODELS_DIR/gemma-4-E4B-it-Q4_K_M.gguf"
            ;;
        qwen|qwen3|qwen3.5|gwen|gwen3|gwen3.5)
            gguf_path="$MODELS_DIR/Qwen3.5-4B-Q4_K_S.gguf"
            ;;
        *)
            # Если передано имя без расширения, добавляем .gguf
            if [[ -f "$model" ]]; then
                gguf_path="$model"
            elif [[ -f "$MODELS_DIR/$model.gguf" ]]; then
                gguf_path="$MODELS_DIR/$model.gguf"
            else
                echo "ОШИБКА: неизвестная модель '$model', попробуйте полный путь" >&2
                exit 1
            fi
            ;;
    esac

    echo "$gguf_path"
}

GGUF="$(resolve_gguf "$MODEL")"

if [[ ! -f "$GGUF" ]]; then
    echo "ОШИБКА: файл модели не найден: $GGUF" >&2
    echo "Доступные модели в $MODELS_DIR:" >&2
    ls "$MODELS_DIR"/*.gguf 2>/dev/null || echo "(нет .gguf файлов)" >&2
    exit 1
fi

# ----------------------------------------------------------------------
# Подготовка лог-файла (проверка возможности записи)
# ----------------------------------------------------------------------
LOG_DIR="$(dirname "$LOG_FILE")"
mkdir -p "$LOG_DIR" 2>/dev/null || {
    echo "ОШИБКА: не удалось создать каталог для логов: $LOG_DIR" >&2
    LOG_FILE="/tmp/llama-server.log"  # fallback
    echo "Использую $LOG_FILE" >&2
}

# ----------------------------------------------------------------------
# Запуск сервера
# ----------------------------------------------------------------------
echo "Запуск llama.cpp сервера..."
echo "  Модель: $GGUF"
echo "  Порт: $PORT"
echo "  Лог: $LOG_FILE"

# setsid полностью отвязывает сервер от сессии/process-group запускающей
# оболочки, чтобы он не погибал при закрытии терминала или завершении
# родительского процесса (nohup alone спасает только от SIGHUP).
setsid nohup "$LLAMA_SERVER" \
    --model "$GGUF" \
    --port "$PORT" \
    --ctx-size 8192 \
    --n-gpu-layers 0 \
    --parallel 1 \
    --threads 4 \
    --threads-batch 4 \
    --cache-type-k q4_0 \
    --cache-type-v q4_0 \
    --cache-ram 2048 \
    --timeout 900 \
    > "$LOG_FILE" 2>&1 < /dev/null &

SERVER_PID=$!
echo "Сервер запущен (PID: $SERVER_PID)"

# Ожидание готовности (макс. 60 сек)
echo -n "Ожидание готовности сервера"
for i in $(seq 1 60); do
    sleep 1
    if curl -s "http://localhost:$PORT/v1/models" >/dev/null 2>&1; then
        echo " ГОТОВО!"
        echo "Сервер доступен на http://localhost:$PORT"
        exit 0
    fi
    echo -n "."
done

echo " ТАЙМАУТ!"
echo "Сервер не запустился за 60 секунд. Проверьте лог: $LOG_FILE"
exit 1