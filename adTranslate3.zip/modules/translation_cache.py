import os
import json
import signal
import atexit
import hashlib
import threading
from typing import Optional

from cachetools import LRUCache

from .utils import STOP_EVENT

_config_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config")


class TranslationCache:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls, cache_path: str = None):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self, cache_path: str = None):
        if self._initialized:
            return
        self._initialized = True
        if cache_path is None:
            cache_path = os.path.join(_config_dir, "translation_cache.json")
        self.cache_path = cache_path
        self._cache: LRUCache = LRUCache(maxsize=10000)
        self._dirty = False
        self._load()
        atexit.register(self.save)
        for sig in (signal.SIGTERM, signal.SIGINT):
            prev = signal.getsignal(sig)
            def _handler(signum, frame, _prev=prev):
                STOP_EVENT.set()
                self.save()
                if callable(_prev):
                    _prev(signum, frame)
                elif _prev == signal.SIG_DFL:
                    signal.signal(signum, signal.SIG_DFL)
                    os.kill(os.getpid(), signum)
            signal.signal(sig, _handler)

    def _load(self):
        if not os.path.exists(self.cache_path):
            return
        try:
            with open(self.cache_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            for key, value in data.items():
                self._cache[key] = value
        except Exception:
            pass

    def save(self):
        if not self._dirty:
            return
        try:
            with open(self.cache_path, "w", encoding="utf-8") as f:
                json.dump(dict(self._cache), f, ensure_ascii=False)
            self._dirty = False
        except Exception:
            pass

    def _key(self, text: str, lang: str) -> str:
        h = hashlib.sha256(text.encode('utf-8')).hexdigest()
        return f"{lang}:{h}"

    def get(self, text: str, lang: str) -> Optional[str]:
        return self._cache.get(self._key(text, lang))

    def put(self, text: str, lang: str, translation: str):
        self._cache[self._key(text, lang)] = translation
        self._dirty = True
        if len(self._cache) % 500 == 0:
            self.save()
