import re
import logging
from typing import List, Optional, Tuple

import fitz

from .models import Block, make_block, Span

logger = logging.getLogger(__name__)

TABLE_CAPTION_RE = re.compile(r'^\s*(?:Table|Таблица|Табл\.?)\s+\d+', re.I)
TABLE_CAPTION_STRICT_RE = re.compile(r'^\s*(?:Table|Таблица|Табл\.?)\s+\d+\s*[|:.–—-]', re.I)

_TABLE_STRATEGIES = [
    {"strategy": "lines_strict", "vertical_strategy": "lines_strict",
     "horizontal_strategy": "lines_strict", "snap_tolerance": 5, "join_tolerance": 5},
    {"strategy": "text", "vertical_strategy": "text",
     "horizontal_strategy": "text", "snap_tolerance": 5, "join_tolerance": 5},
]


def _extract_rows_safely(tab) -> Optional[List[List[str]]]:
    """Безопасно извлекает строки из Table. tab.extract() может вернуть None."""
    try:
        rows = tab.extract()
    except Exception:
        return None
    if not rows:
        return None
    cleaned = [[cell if cell else "" for cell in (row or [])] for row in rows]
    if not cleaned or all(not str(c).strip() for row in cleaned for c in row):
        return None
    if len(cleaned) < 2 or len(cleaned[0]) < 2:
        return None
    return cleaned


def extract_tables(page: fitz.Page, page_num: int) -> List[Block]:
    """Детекция таблиц PyMuPDF. Перебирает несколько стратегий и фильтрует дубликаты по bbox."""
    table_blocks: List[Block] = []
    seen_bboxes: List[fitz.Rect] = []

    for params in _TABLE_STRATEGIES:
        try:
            tables = page.find_tables(**params)
        except Exception as e:
            logger.debug(f"find_tables (стр. {page_num}, params={params['strategy']}): {e}")
            continue

        for tab in tables:
            try:
                rows = _extract_rows_safely(tab)
                if not rows:
                    continue
                tab_rect = fitz.Rect(tab.bbox)
                if any(_rect_gap(tab_rect, r) <= 3 or
                       (fitz.Rect(tab_rect) & r).get_area() / max(tab_rect.get_area(), 1.0) > 0.85
                       for r in seen_bboxes):
                    continue
                seen_bboxes.append(tab_rect)
                table_blocks.append(make_block(
                    type="table", page_num=page_num, bbox=tuple(tab.bbox), table_data=rows))
            except Exception:
                continue
    return table_blocks


def _row_columns(block: Block, tol: float = 8.0) -> Optional[List[float]]:
    if not block.lines:
        return None
    if len(block.lines) == 1:
        xs = [s.bbox[0] for s in block.lines[0].spans if s.text.strip()]
        if len(xs) < 2:
            return None
        gaps = [b - a for a, b in zip(sorted(xs), sorted(xs)[1:])]
        if gaps and min(gaps) < 5:
            return None
    else:
        xs = [ln.bbox[0] for ln in block.lines if ln.spans]
        if len(xs) < 2:
            return None
    clusters = []
    for x in sorted(xs):
        if clusters and x - clusters[-1][-1] <= tol:
            clusters[-1].append(x)
        else:
            clusters.append([x])
    if len(clusters) < 2:
        return None
    return [sum(c) / len(c) for c in clusters]


def _columns_align(ref: List[float], cols: List[float], tol: float = 10.0, min_frac: float = 0.5) -> bool:
    if not ref or not cols:
        return False
    matched = 0
    for x in cols:
        if any(abs(x - y) <= tol for y in ref):
            matched += 1
    return matched / len(cols) >= min_frac


def _build_table_row(block: Block, columns: List[float]) -> List[str]:
    cells = [""] * len(columns)

    def _cell_text(u) -> str:
        if isinstance(u, Span):
            return u.text.strip()
        return " ".join(s.text for s in u.spans if s.text.strip()).strip()

    def _cell_x(u) -> float:
        if isinstance(u, Span):
            return u.bbox[0]
        return u.bbox[0] if u.spans else 0.0

    units = block.lines[0].spans if len(block.lines) == 1 else block.lines
    for u in units:
        text = _cell_text(u)
        if not text:
            continue
        k = min(range(len(columns)), key=lambda kk: abs(_cell_x(u) - columns[kk]))
        if cells[k]:
            cells[k] += " " + text
        else:
            cells[k] = text
    return cells


def _merge_span_table(caption: Block, row_blocks: List[Block]) -> Block:
    columns = []
    for rb in row_blocks:
        cols = _row_columns(rb) or []
        for c in cols:
            if not any(abs(c - x) <= 10 for x in columns):
                columns.append(c)
    columns.sort()
    data = [_build_table_row(rb, columns) for rb in row_blocks]
    xs = [caption.bbox[0], *[rb.bbox[0] for rb in row_blocks]]
    ys = [caption.bbox[1], *[rb.bbox[1] for rb in row_blocks]]
    xe = [caption.bbox[2], *[rb.bbox[2] for rb in row_blocks]]
    ye = [caption.bbox[3], *[rb.bbox[3] for rb in row_blocks]]
    bbox = (min(xs), min(ys), max(xe), max(ye))
    block = make_block(type="table", page_num=caption.page_num, bbox=bbox,
                       lines=list(caption.lines), caption=caption.text, table_data=data)
    for rb in row_blocks:
        block.lines.extend(rb.lines)
    return block


def _find_span_table_blocks(blocks: List[Block]) -> Tuple[List[Block], List[Block]]:
    table_blocks = []
    merged_list = []
    i = 0
    n = len(blocks)
    while i < n:
        b = blocks[i]
        if b.type == "text" and _is_table_caption(b.text):
            rows = []
            ref = None
            j = i + 1
            while j < n:
                nb = blocks[j]
                if nb.type != "text":
                    break
                cols = _row_columns(nb)
                if cols is None:
                    break
                if ref is None:
                    ref = cols
                elif not _columns_align(ref, cols):
                    break
                rows.append(nb)
                j += 1
            if rows:
                merged = _merge_span_table(b, rows)
                table_blocks.append(merged)
                merged_list.append(merged)
                i = j
                continue
        merged_list.append(b)
        i += 1
    return table_blocks, merged_list


def intersection_ratio(block_bbox, table_bbox) -> float:
    x0 = max(block_bbox[0], table_bbox[0])
    y0 = max(block_bbox[1], table_bbox[1])
    x1 = min(block_bbox[2], table_bbox[2])
    y1 = min(block_bbox[3], table_bbox[3])
    if x1 <= x0 or y1 <= y0:
        return 0.0
    intersection = (x1 - x0) * (y1 - y0)
    block_area = (block_bbox[2] - block_bbox[0]) * (block_bbox[3] - block_bbox[1])
    if block_area == 0:
        return 0.0
    return intersection / block_area


def _heuristic_table_data(text: str) -> Optional[List[List[str]]]:
    lines = [ln for ln in text.split('\n') if ln.strip()]
    if len(lines) < 2:
        return None
    ends_with_punct = sum(1 for ln in lines if re.search(r'[.!?;]\s*$', ln))
    if ends_with_punct > len(lines) * 0.4:
        return None
    rows = []
    for ln in lines:
        cells = [c.strip() for c in re.split(r'\s{3,}|\t+', ln.strip()) if c.strip()]
        if len(cells) < 2:
            return None
        rows.append(cells)
    col_counts = {len(r) for r in rows}
    if len(col_counts) != 1:
        return None
    return rows


def _looks_like_table_data(text: str) -> bool:
    lines = [ln for ln in text.split('\n') if ln.strip()]
    if len(lines) < 2:
        return False
    if any(re.search(r'[.!?]\s*$', ln) for ln in lines[:-1]):
        return False
    col_counts = {len(re.split(r'\s{3,}|\t+', ln)) for ln in lines}
    if len(col_counts) == 1 and next(iter(col_counts)) >= 2:
        return True
    if all(len(ln) < 60 for ln in lines):
        return True
    return False


def _cluster_columns_by_x(blocks: List[Block], eps: float = 15.0, min_samples: int = 2) -> List[float]:
    all_x = []
    for b in blocks:
        if b.type in ("table", "figure", "empty"):
            continue
        for ln in b.lines:
            line_text = "".join(s.text for s in ln.spans).strip()
            if len(line_text) > 60:
                continue
            for s in ln.spans:
                if s.text.strip():
                    all_x.append(s.bbox[0])
    if not all_x:
        return []
    all_x.sort()
    clusters = []
    for x in all_x:
        if clusters and x - clusters[-1][-1] <= eps:
            clusters[-1].append(x)
        else:
            clusters.append([x])
    result = []
    for c in clusters:
        if len(c) >= min_samples:
            result.append(sum(c) / len(c))
    return sorted(result)


def consolidate_tables(blocks: List[Block], found_table_blocks: Optional[List[Block]] = None) -> List[Block]:
    page_columns = _cluster_columns_by_x(blocks)
    if found_table_blocks:
        for block in blocks:
            if block.type == "table":
                continue
            for table in found_table_blocks:
                if intersection_ratio(block.bbox, table.bbox) > 0.50:
                    if _heuristic_table_data(block.text) or _looks_like_table_data(block.text):
                        block.type = "table"
                        break
    for b in blocks:
        if b.type in ("table", "figure"):
            continue
        rows = _heuristic_table_data(b.text)
        if rows:
            b.type = "table"
            b.table_data = rows
            continue
        if page_columns and len(page_columns) >= 2 and b.type == "text":
            block_xs = []
            for ln in b.lines:
                for s in ln.spans:
                    if s.text.strip():
                        block_xs.append(s.bbox[0])
            if block_xs:
                matched = sum(1 for x in block_xs if any(abs(x - c) <= 12 for c in page_columns))
                if matched / len(block_xs) >= 0.6 and len(b.lines) >= 2:
                    b.type = "table"
    i = 0
    n = len(blocks)
    while i < n:
        b = blocks[i]
        if b is None or b.type not in ("text", "heading", "table"):
            i += 1
            continue
        if b.table_data:
            i += 1
            continue
        if not _is_table_caption(b.text):
            i += 1
            continue
        j = i + 1
        nb = blocks[j] if j < n else None
        if nb is not None and nb.type == "table" and nb.table_data:
            nb.caption = b.text
            blocks[i] = None
            i = j
            continue
        if b.type != "table":
            b.type = "table"
        rows = []
        ref = None
        j = i + 1
        while j < n:
            nb = blocks[j]
            if nb is None or nb.type not in ("text", "paragraph", "list"):
                break
            cols = _row_columns(nb)
            if cols is not None and (ref is None or _columns_align(ref, cols)):
                if ref is None:
                    ref = cols
                rows.append(nb)
                j += 1
                continue
            if _heuristic_table_data(nb.text) is not None or _looks_like_table_data(nb.text):
                rows.append(nb)
                j += 1
            else:
                break
        if rows:
            merged = _merge_span_table(b, rows)
            b.bbox = merged.bbox
            b.lines = merged.lines
            b.caption = merged.caption
            b.table_data = merged.table_data
        i = j
    return [b for b in blocks if b is not None and b.type != "empty"
            and not (b.type == "table" and b.table_data is None and not b.text.strip())]


def _is_table_caption(text: str) -> bool:
    if not text:
        return False
    if TABLE_CAPTION_STRICT_RE.match(text):
        return True
    if not TABLE_CAPTION_RE.match(text):
        return False
    return len(text) <= 120 and len(text.split()) <= 15