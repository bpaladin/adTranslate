#!/usr/bin/env python3
"""
PDF Translator — единый скрипт для перевода и реферирования PDF-документов.
Поддерживает Google Translate, OpenRouter/SprutDock и локальный llama.cpp.
"""

import os
import sys
import logging
import argparse

from modules.utils import __version__, _format_time
from modules.logging_setup import logger
from modules.config import BLOCK_TIMEOUT
from modules.pipeline import process_pdf


def main():
    parser = argparse.ArgumentParser(description="PDF Translator — единый скрипт")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("input", help="Входной PDF файл")
    parser.add_argument("-l", "--lang", default="ru", help="Целевой язык (по умолчанию: ru)")
    parser.add_argument("-t", "--translator", default="google", choices=["google", "llama", "openrouter", "sprut"],
                        help="Переводчик (по умолчанию: google)")
    parser.add_argument("--llama-url", default="http://localhost:8080/v1", help="URL llama.cpp сервера")
    parser.add_argument("--llama-model", help="Ожидаемое имя модели")
    parser.add_argument("--sprut-model", default=os.getenv("SPRUT_MODEL"),
                        help="Модель для SprutDock (например, z-ai/glm-5.2:free)")
    parser.add_argument("--no-auto-find", action="store_true", help="Отключить автоматический поиск сервера")
    parser.add_argument("--summary", action="store_true", help="Режим реферата")
    parser.add_argument("--summary-translator", choices=["google", "llama", "openrouter", "sprut"],
                        default="llama", help="Генератор реферата (по умолчанию: llama)")
    parser.add_argument("--summary-lang-translator", choices=["google", "llama", "openrouter", "sprut"],
                        default="google", help="Переводчик реферата (по умолчанию: google)")
    parser.add_argument("--workers", type=int, default=min(8, (os.cpu_count() or 1) * 2), help="Число воркеров")
    parser.add_argument("--block-timeout", type=int, default=BLOCK_TIMEOUT, help="Максимум секунд на один блок")
    parser.add_argument("--dark-html", action="store_true", default=True, help="Тёмная тема HTML (по умолчанию: вкл)")
    parser.add_argument("--light-html", action="store_true", help="Светлая тема HTML")
    parser.add_argument("-q", "--quiet", action="store_true", help="Тихий режим")
    parser.add_argument("-v", "--verbose", action="store_true", help="Подробный вывод")
    args = parser.parse_args()

    if args.verbose:
        logger.setLevel(logging.DEBUG)
        for h in logger.handlers:
            h.setLevel(logging.DEBUG)

    dark_html = not args.light_html
    input_base = os.path.splitext(args.input)[0]
    output_html = f"{input_base}_summary.html" if args.summary else f"{input_base}_translate.html"

    logger.info("=" * 60)
    logger.info(f"PDF TRANSLATOR — {args.translator.upper()} v{__version__}")
    logger.info("=" * 60)

    try:
        result = process_pdf(
            pdf_path=args.input, output_html=output_html, lang=args.lang, translator_type=args.translator,
            llama_url=args.llama_url, llama_model=args.llama_model, auto_find=not args.no_auto_find,
            max_workers=args.workers, timeout=args.block_timeout, quiet=args.quiet, summary_mode=args.summary,
            summary_translator_type=args.summary_translator, translate_translator_type=args.summary_lang_translator,
            dark_html=dark_html, sprut_model=args.sprut_model,
        )

        stats = result["stats"]
        logger.info("=" * 60)
        if stats.get("summary_mode", False):
            logger.info(" СТАТИСТИКА ГЕНЕРАЦИИ РЕФЕРАТА:")
            logger.info(f"    Обработано чанков: {stats.get('chunks', 0)}")
            if stats.get("tokens", 0) > 0:
                logger.info(f"    Сгенерировано токенов (приблиз.): {stats['tokens']}")
            if stats.get("speed", 0) > 0:
                logger.info(f"    Скорость: {stats['speed']:.1f} токенов/сек")
            if stats.get("model"):
                logger.info(f"    Модель: {stats['model']}")
            if stats.get("time", 0) > 0:
                logger.info(f"    Время генерации: {_format_time(stats['time'])}")
        else:
            logger.info(" СТАТИСТИКА ПЕРЕВОДА:")
            logger.info(f"    Переведено: {stats.get('success', 0)}")
            logger.info(f"    Из кэша:   {stats.get('cached', 0)}")
            logger.info(f"    Пропущено:  {stats.get('skipped', 0)}")
            logger.info(f"    Ошибок:     {stats.get('failed', 0)}")
            if stats.get("error"):
                logger.error(f"   Причина: {stats['error']}")

        timings = stats.get("timings", {})
        if timings:
            logger.info("  ПРОФИЛИРОВАНИЕ:")
            for stage, t in timings.items():
                logger.info(f"   {stage}: {_format_time(t)}")
        logger.info("=" * 60)
        logger.info(f" Готово: {output_html}")

    except KeyboardInterrupt:
        logger.warning(" Прервано пользователем")
        sys.exit(1)
    except Exception as e:
        logger.error(f" Ошибка: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
