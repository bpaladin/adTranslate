import re
import logging
from typing import List, Optional

from .models import Block

logger = logging.getLogger(__name__)

TABLE_CAPTION_RE = re.compile(r'^\s*(?:Table|Таблица|Табл\.?)\s+\d+', re.I)
TABLE_CAPTION_STRICT_RE = re.compile(r'^\s*(?:Table|Таблица|Табл\.?)\s+\d+\s*[|:.–—-]', re.I)


def _is_table_caption(text: str) -> bool:
    if not text:
        return False
    if TABLE_CAPTION_STRICT_RE.match(text):
        return True
    if not TABLE_CAPTION_RE.match(text):
        return False
    return len(text) <= 120 and len(text.split()) <= 15


def _heuristic_table_data(text: str) -> Optional[List[List[str]]]:
    lines = [ln for ln in text.split('\n') if ln.strip()]
    if len(lines) < 2:
        return None
    ends_with_punct = sum(1 for ln in lines if re.search(r'[.!?;]\s*$', ln))
    if ends_with_punct > len(lines) * 0.4:
        return None
    rows = []
    for ln in lines:
        cells = [c.strip() for c in re.split(r'\s{3,}|\t+', ln.strip()) if c.strip()]
        if len(cells) < 2:
            return None
        rows.append(cells)
    col_counts = {len(r) for r in rows}
    if len(col_counts) != 1:
        return None
    return rows


def _looks_like_table_data(text: str) -> bool:
    lines = [ln for ln in text.split('\n') if ln.strip()]
    if len(lines) < 2:
        return False
    if any(re.search(r'[.!?]\s*$', ln) for ln in lines[:-1]):
        return False
    col_counts = {len(re.split(r'\s{3,}|\t+', ln)) for ln in lines}
    if len(col_counts) == 1 and next(iter(col_counts)) >= 2:
        return True
    if all(len(ln) < 60 for ln in lines):
        return True
    return False


def _row_columns(block: Block, tol: float = 8.0) -> Optional[List[float]]:
    if not block.lines:
        return None
    xs = [ln.bbox[0] for ln in block.lines if ln.spans]
    if len(xs) < 2:
        return None
    clusters = []
    for x in sorted(xs):
        if clusters and x - clusters[-1][-1] <= tol:
            clusters[-1].append(x)
        else:
            clusters.append([x])
    if len(clusters) < 2:
        return None
    return [sum(c) / len(c) for c in clusters]


def _columns_align(ref: List[float], cols: List[float], tol: float = 10.0, min_frac: float = 0.5) -> bool:
    if not ref or not cols:
        return False
    matched = sum(1 for x in cols if any(abs(x - y) <= tol for y in ref))
    return matched / len(cols) >= min_frac


def _build_table_row(block: Block, columns: List[float]) -> List[str]:
    cells = [""] * len(columns)
    for ln in block.lines:
        for span in ln.spans:
            text = span.text.strip()
            if not text:
                continue
            k = min(range(len(columns)), key=lambda kk: abs(span.bbox[0] - columns[kk]))
            cells[k] = (cells[k] + " " + text) if cells[k] else text
    return cells


def _merge_span_table(caption: Block, row_blocks: List[Block]) -> Block:
    columns = []
    for rb in row_blocks:
        cols = _row_columns(rb) or []
        for c in cols:
            if not any(abs(c - x) <= 10 for x in columns):
                columns.append(c)
    columns.sort()
    data = [_build_table_row(rb, columns) for rb in row_blocks]
    xs = [caption.bbox[0], *[rb.bbox[0] for rb in row_blocks]]
    ys = [caption.bbox[1], *[rb.bbox[1] for rb in row_blocks]]
    xe = [caption.bbox[2], *[rb.bbox[2] for rb in row_blocks]]
    ye = [caption.bbox[3], *[rb.bbox[3] for rb in row_blocks]]
    bbox = (min(xs), min(ys), max(xe), max(ye))
    block = Block(type="table", page_num=caption.page_num, bbox=bbox,
                  lines=list(caption.lines), caption=caption.text, table_data=data)
    for rb in row_blocks:
        block.lines.extend(rb.lines)
    return block


def consolidate_tables(blocks: List[Block]) -> List[Block]:
    for b in blocks:
        if b.type in ("table", "figure"):
            continue
        rows = _heuristic_table_data(b.text)
        if rows:
            b.type = "table"
            b.table_data = rows
            continue

    i = 0
    n = len(blocks)
    while i < n:
        b = blocks[i]
        if b is None or b.type not in ("text", "heading", "table"):
            i += 1
            continue
        if b.table_data:
            i += 1
            continue
        if not _is_table_caption(b.text):
            i += 1
            continue
        j = i + 1
        nb = blocks[j] if j < n else None
        if nb is not None and nb.type == "table" and nb.table_data:
            nb.caption = b.text
            blocks[i] = None
            i = j
            continue
        if b.type != "table":
            b.type = "table"
        rows = []
        ref = None
        j = i + 1
        while j < n:
            nb = blocks[j]
            if nb is None or nb.type not in ("text", "paragraph", "list"):
                break
            cols = _row_columns(nb)
            if cols is not None and (ref is None or _columns_align(ref, cols)):
                if ref is None:
                    ref = cols
                rows.append(nb)
                j += 1
                continue
            if _heuristic_table_data(nb.text) is not None or _looks_like_table_data(nb.text):
                rows.append(nb)
                j += 1
            else:
                break
        if rows:
            merged = _merge_span_table(b, rows)
            b.bbox = merged.bbox
            b.lines = merged.lines
            b.caption = merged.caption
            b.table_data = merged.table_data
        i = j
    return [b for b in blocks if b is not None and b.type != "empty"
            and not (b.type == "table" and b.table_data is None and not b.text.strip())]
