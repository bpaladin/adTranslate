import base64
import logging
from typing import List, Optional

import pdfstruct

from .models import make_block, make_span, make_line, Page

logger = logging.getLogger(__name__)


def _bbox_tuple(bbox) -> tuple:
    if bbox is None:
        return (0, 0, 0, 0)
    return (bbox.x0, bbox.y0, bbox.x1, bbox.y1)


def _font_flags(font) -> int:
    flags = 0
    if font and font.is_bold:
        flags |= 2 ** 0
    if font and font.is_italic:
        flags |= 2 ** 1
    return flags


def _font_color_int(font) -> int:
    if not font or not font.color:
        return 0
    c = font.color.lstrip('#')
    if len(c) == 6:
        try:
            return int(c, 16)
        except ValueError:
            return 0
    return 0


def _convert_paragraph(para, page_num: int) -> make_block:
    block = make_block(type="text", page_num=page_num, bbox=_bbox_tuple(para.bbox))
    for ps_line in para.lines:
        spans = []
        if ps_line.characters:
            cur_text = ""
            cur_font = None
            for char in ps_line.characters:
                same_font = (cur_font is not None and char.font and
                             char.font.name == cur_font.name and
                             char.font.size == cur_font.size and
                             char.font.is_bold == cur_font.is_bold and
                             char.font.is_italic == cur_font.is_italic)
                if same_font:
                    cur_text += char.text
                else:
                    if cur_text.strip():
                        spans.append(make_span(
                            text=cur_text,
                            font=cur_font.name if cur_font else "",
                            size=cur_font.size if cur_font else 12,
                            flags=_font_flags(cur_font),
                            color=_font_color_int(cur_font),
                            bbox=_bbox_tuple(char.bbox) if len(spans) == 0 else _bbox_tuple(char.bbox),
                        ))
                    cur_text = char.text
                    cur_font = char.font
            if cur_text.strip():
                spans.append(make_span(
                    text=cur_text,
                    font=cur_font.name if cur_font else "",
                    size=cur_font.size if cur_font else 12,
                    flags=_font_flags(cur_font),
                    color=_font_color_int(cur_font),
                    bbox=_bbox_tuple(ps_line.bbox),
                ))
        elif ps_line.text.strip():
            spans.append(make_span(
                text=ps_line.text,
                font=ps_line.font.name if ps_line.font else "",
                size=ps_line.font.size if ps_line.font else 12,
                flags=_font_flags(ps_line.font),
                color=_font_color_int(ps_line.font),
                bbox=_bbox_tuple(ps_line.bbox),
            ))
        if spans:
            line_bbox = _bbox_tuple(ps_line.bbox)
            block.lines.append(make_line(spans=spans, bbox=line_bbox, y0=line_bbox[1]))
    return block


def _convert_table(table, page_num: int) -> make_block:
    table_data = table.to_list()
    bbox = _bbox_tuple(table.bbox)
    caption = table.caption
    return make_block(type="table", page_num=page_num, bbox=bbox,
                      table_data=table_data, caption=caption)


def _convert_image(img_info, page_num: int) -> Optional[make_block]:
    if img_info.extraction_error:
        return None
    if img_info.is_duplicate:
        return None
    data = img_info.image_bytes
    if not data:
        return None
    image_data = base64.b64encode(data).decode()
    ext = img_info.format.lower() if img_info.format else "png"
    if ext == "jpeg":
        ext = "jpg"
    bbox = _bbox_tuple(img_info.bbox)
    caption = img_info.caption
    return make_block(type="figure", page_num=page_num, bbox=bbox,
                      image_data=image_data, image_ext=ext, caption=caption)


class PDFExtractor:
    def __init__(self, path: str, crop_top: float = 40.0, crop_bottom: float = 45.0):
        self.path = path
        self.crop_top = crop_top
        self.crop_bottom = crop_bottom

    def extract(self) -> List[Page]:
        try:
            doc = pdfstruct.parse(
                self.path,
                detect_tables=True,
                detect_headers_footers=True,
                detect_lists=True,
                detect_columns=True,
                extract_images=True,
                extract_image_data=True,
            )
        except Exception as e:
            logger.error(f"pdfstructx parse error: {e}")
            return []

        pages = []
        for ps_page in doc.pages:
            page_num = ps_page.number
            page_blocks = []

            for para in ps_page.paragraphs:
                if para.bbox:
                    top_y = self.crop_top
                    bottom_y = ps_page.height - self.crop_bottom
                    if para.bbox.y1 < top_y or para.bbox.y0 > bottom_y:
                        continue
                block = _convert_paragraph(para, page_num)
                if block.lines:
                    page_blocks.append(block)

            for table in ps_page.tables:
                page_blocks.append(_convert_table(table, page_num))

            for img_info in ps_page.images:
                fig_block = _convert_image(img_info, page_num)
                if fig_block:
                    page_blocks.append(fig_block)

            page_blocks.sort(key=lambda b: (b.bbox[1], b.bbox[0]))
            pages.append(Page(num=page_num, blocks=page_blocks,
                              width=ps_page.width, height=ps_page.height))

        total_text = "".join(block.text for page in pages for block in page.blocks)
        if len(total_text.strip()) < 10:
            logger.warning(" pdfstructx: текст не найден (возможно, отсканированный PDF)")

        return pages
