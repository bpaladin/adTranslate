"""Main PDF processing pipeline orchestrator."""

import os
import sys
import re
import statistics
from typing import Dict, Any, Optional

import fitz

from .utils import stage_timer, _format_time
from .logging_setup import logger
from .models import Page
from .config import BLOCK_TIMEOUT
from .pdf_extraction import PDFExtractor
from .table_detection import consolidate_tables
from .figure_extraction import extract_vector_figures
from .classifier import _classifier
from .citation import _split_ref_heading
from .summary import generate_summary
from .html_generation import generate_html, generate_summary_html
from .translator_factory import create_translator
from .translation_pipeline import TranslationPipeline

BACK_MATTER_RE = re.compile(
    r'^\s*(Acknowledg(?:ement|ment)s?\b|Author\s+contributions?\b|Funding\b|'
    r'Competing\s+interests?\b|Additional\s+information\b|Supplementary\s+information\b|'
    r'Supplementary\s+notes?\b|Correspondence\b|Reprints?\s+and\s+permissions?\b|'
    r'Publisher\s*\'?s?\s+note\b|Open\s+Access\b|Conflict(?:s)?\s+of\s+interest\b|'
    r'Ethics\s+declarations?\b|Ethical\s+approval\b|Consent\s+to\s+participate\b|'
    r'Consent\s+for\s+publication\b|Data\s+availability\b|Code\s+availability\b|'
    r'Availability\s+of\s+data\s+and\s+materials\b|Declarations?\b|Received[:.]?\s+\d|'
    r'Presented\s+at\b)', re.IGNORECASE
)


def process_pdf(
    pdf_path: str,
    output_html: str,
    lang: str = "ru",
    translator_type: str = "google",
    llama_url: str = "http://localhost:8080/v1",
    llama_model: Optional[str] = None,
    auto_find: bool = True,
    max_workers: int = 8,
    timeout: int = BLOCK_TIMEOUT,
    quiet: bool = False,
    summary_mode: bool = False,
    summary_translator_type: str = "llama",
    translate_translator_type: str = "google",
    dark_html: bool = True,
    sprut_model: Optional[str] = None,
) -> Dict[str, Any]:

    timings: Dict[str, float] = {}
    total_images = 0
    total_tables = 0

    with stage_timer("1. Извлечение PDF", timings):
        extractor = PDFExtractor(pdf_path)
        pages = extractor.extract()

        for page in pages:
            total_tables += sum(1 for b in page.blocks if b.type == "table")
            total_images += sum(1 for b in page.blocks if b.type == "figure")

        doc = fitz.open(pdf_path)
        for page in pages:
            text_blocks = [b for b in page.blocks if b.type not in ("figure", "table")]
            try:
                fitz_page = doc[page.num - 1]
                used_bboxes = [fb.bbox for fb in page.blocks if fb.type == "figure"]
                table_bboxes = [tb.bbox for tb in page.blocks if tb.type == "table"]
                vector_blocks, text_blocks = extract_vector_figures(
                    fitz_page, page.num, text_blocks,
                    used_bboxes=used_bboxes, table_bboxes=table_bboxes)
                page.blocks = [b for b in page.blocks if b.type in ("figure", "table")]
                page.blocks.extend(vector_blocks)
                page.blocks.extend(text_blocks)
                total_images += len(vector_blocks)
            except Exception as e:
                logger.warning(f"Ошибка извлечения векторных фигур: {e}")
        doc.close()

        total_text = "".join(block.text for page in pages for block in page.blocks)
        if len(total_text.strip()) < 10:
            logger.error(" В PDF не найден текст (возможно, файл состоит только из изображений или отсканирован).")
            sys.exit(1)
    logger.info(f"   Извлечено {len(pages)} стр., {total_images} изобр., {total_tables} табл.")

    with stage_timer("2. Классификация", timings):
        for page in pages:
            all_sizes = [span.size for block in page.blocks
                         if block.type in ("paragraph", "heading", "metadata")
                         for line in block.lines for span in line.spans]
            avg_size = statistics.median(all_sizes) if all_sizes else 12.0
            for block in page.blocks:
                if block.type == "text":
                    block.type = _classifier.classify(block, page.width, avg_size)

    with stage_timer("3. Пост-обработка", timings):
        for page in pages:
            new_blocks = []
            for block in page.blocks:
                new_blocks.extend(_split_ref_heading(block))
            page.blocks = new_blocks
        in_refs = False
        for page in pages:
            for block in page.blocks:
                if block.type == "reference_heading":
                    in_refs = True
                    continue
                if in_refs:
                    if BACK_MATTER_RE.match(block.text):
                        in_refs = False
                    elif block.type not in ("figure", "table"):
                        block.type = "reference"
        for page in pages:
            page.blocks = consolidate_tables(page.blocks)

    if summary_mode:
        with stage_timer("4. Генерация реферата", timings):
            logger.info(" Режим реферата...")
            if summary_translator_type == "google":
                summary_translator_type = "llama"
            result = generate_summary(
                pages, summary_translator_type=summary_translator_type,
                translate_translator_type=translate_translator_type, lang=lang,
                llama_url=llama_url, llama_model=llama_model, auto_find=auto_find,
                sprut_model=sprut_model, quiet=quiet)
            summary_html = result["summary_html"]
            gen_stats = result["stats"]

        with stage_timer("5. HTML реферата", timings):
            generate_summary_html(pages, summary_html, f"Реферат: {os.path.basename(pdf_path)}", output_html)
            logger.info(f"   HTML сохранён: {output_html}")

        return {"stats": {"chunks": gen_stats.get("chunks", 0), "tokens": gen_stats.get("tokens", 0),
                          "speed": gen_stats.get("speed", 0), "model": gen_stats.get("model", ""),
                          "time": gen_stats.get("time", 0), "summary_mode": True, "timings": timings},
                "pages": len(pages), "images": total_images, "tables": total_tables, "summary": True}

    with stage_timer("4. Перевод", timings):
        logger.info(f" Перевод на {lang} ({translator_type})...")
        try:
            translator, fallback = create_translator(
                translator_type, lang, llama_url=llama_url, llama_model=llama_model,
                auto_find=auto_find, sprut_model=sprut_model)
        except RuntimeError as e:
            logger.error(f"   Не удалось инициализировать переводчик '{translator_type}': {e}")
            return {"stats": {"error": str(e)}, "pages": 0, "images": 0, "tables": 0}

        effective_workers = 1 if translator_type == "llama" else max_workers
        if translator_type == "llama" and not quiet:
            logger.info("   Локальный сервер: ограничено до 1 воркера (параллельные запросы вызывают зацикливание/галлюцинации)")

        pipeline = TranslationPipeline(
            translator=translator, fallback=fallback,
            max_workers=effective_workers, timeout=timeout,
            is_local=(translator_type == "llama"), translator_type=translator_type,
        )

        all_blocks = [block for page in pages for block in page.blocks]
        pipeline.translate_blocks(all_blocks, lang, quiet=quiet)

    with stage_timer("5. HTML", timings):
        generate_html(pages, f"Перевод: {os.path.basename(pdf_path)}", output_html, dark=dark_html)
        logger.info(f"   HTML сохранён: {output_html}")

    return {"stats": {**pipeline.stats, "timings": timings}, "pages": len(pages),
            "images": total_images, "tables": total_tables}
